criaCartao(
    'Desenho',
    'Qual desenho tem o Grinch',
    'em um desenho de natal'
)

criaCartao(
    'Filmes',
    'Qual o ator de o fabricante de lagrimas?',
    'Biondo'
)

criaCartao(
    'Serie',
    'Em que serie tem rick?',
    'Em the whalking dead'
)

criaCartao(
    'Desenho',
    'Em que desenho tem alegria?',
    'Divertidamente 1 e 2'
)
